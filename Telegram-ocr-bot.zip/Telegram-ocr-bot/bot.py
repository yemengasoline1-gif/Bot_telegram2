#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
بوت تلجرام لاستخراج بيانات الجوازات وإنشاء Gmail
إصدار 2024 - يعمل على Render.com
"""

import os
import sys
import re
import random
import string
import logging
from datetime import datetime
from io import BytesIO

# مكتبات Telegram
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    CallbackQueryHandler
)

# مكتبات معالجة الصور
try:
    import cv2
    import numpy as np
    from PIL import Image
    import pytesseract
    HAS_IMAGE_LIBS = True
except ImportError as e:
    print(f"⚠️ مكتبة ناقصة: {e}")
    HAS_IMAGE_LIBS = False

# مكتبة Flask للإبقاء حياً
try:
    from flask import Flask
    from threading import Thread
    HAS_FLASK = True
except ImportError:
    HAS_FLASK = False

# ==================== إعدادات البوت ====================
BOT_TOKEN = os.environ.get("BOT_TOKEN")
if not BOT_TOKEN:
    print("❌ خطأ: BOT_TOKEN غير موجود!")
    print("📝 أضف متغير البيئة BOT_TOKEN في Render")
    sys.exit(1)

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ==================== خادم Flask للإبقاء حياً ====================
if HAS_FLASK:
    app = Flask(__name__)

    @app.route('/')
    def home():
        html = """
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>🤖 بوت استخراج بيانات الجوازات</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    margin: 0;
                    padding: 20px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                }
                .container {
                    background: white;
                    padding: 40px;
                    border-radius: 15px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                    max-width: 800px;
                    width: 100%;
                    text-align: center;
                }
                .status {
                    color: #10b981;
                    font-size: 24px;
                    margin-bottom: 20px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="status">✅ البوت يعمل بنجاح</div>
                <h1>🤖 بوت استخراج بيانات الجوازات</h1>
                <p>🟢 الحالة: نشط</p>
                <p>🕒 آخر تحديث: {}</p>
            </div>
        </body>
        </html>
        """.format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        return html

    def run_flask():
        port = int(os.environ.get("PORT", 8080))
        app.run(host="0.0.0.0", port=port, debug=False)

    # بدء Flask في thread منفصل
    flask_thread = Thread(target=run_flask, daemon=True)
    flask_thread.start()
    print("✅ خادم Flask بدأ على المنفذ 8080")

# ==================== دوال المساعدة ====================
class PassportProcessor:
    """معالج بيانات الجوازات"""

    @staticmethod
    def extract_name_from_text(text_arabic, text_english):
        """استخراج الاسم من النصوص"""
        name_patterns = [
            # أنماط عربية
            (r'الاسم[:\s]*([^\n\r]+)', text_arabic),
            (r'اسم[:\s]*([^\n\r]+)', text_arabic),
            (r'المسمى[:\s]*([^\n\r]+)', text_arabic),
            (r'حامل[:\s]*([^\n\r]+)', text_arabic),
            (r'([\u0600-\u06FF]{2,}\s+[\u0600-\u06FF]{2,})', text_arabic),

            # أنماط إنجليزية
            (r'Name[:\s]*([^\n\r]+)', text_english),
            (r'Full[:\s]*Name[:\s]*([^\n\r]+)', text_english),
            (r'Surname[:\s]*([^\n\r]+)', text_english),
            (r'Given[:\s]*Name[:\s]*([^\n\r]+)', text_english),
        ]

        for pattern, text in name_patterns:
            try:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    name = match.group(1).strip()
                    if len(name) > 2:
                        return name
            except:
                continue

        return "محمد أحمد"  # اسم افتراضي إذا لم يتم التعرف

    @staticmethod
    def generate_gmail(name):
        """إنشاء بريد Gmail"""
        # تنظيف الاسم
        clean_name = re.sub(r'[^a-zA-Z]', '', name)
        if len(clean_name) < 3:
            clean_name = "user"

        # توليد اسم مستخدم فريد
        username = f"{clean_name[:4].lower()}{random.randint(1000, 9999)}"

        # التحقق من الطول
        if len(username) > 30:
            username = username[:30]

        return f"{username}@gmail.com"

    @staticmethod
    def generate_passwords(name):
        """توليد كلمات مرور آمنة"""
        clean_name = re.sub(r'[^a-zA-Z]', '', name)
        if len(clean_name) < 3:
            clean_name = "user"

        # كلمة مرور مقتبسة من الاسم
        name_password = f"{clean_name[:3].lower()}{random.randint(100, 999)}!"

        # كلمة مرور قوية
        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        strong_password = ''.join(random.choice(chars) for _ in range(12))

        # كلمة مرور سهلة التذكر
        words = ["Secure", "Safe", "Guard", "Protect"]
        memorable_password = f"{random.choice(words)}{random.choice(words)}{random.randint(10, 99)}"

        return {
            "simple": name_password,
            "strong": strong_password,
            "memorable": memorable_password
        }

# ==================== معالجة الصور ====================
async def process_image(image_bytes):
    """معالجة الصورة واستخراج النصوص"""
    if not HAS_IMAGE_LIBS:
        return "❌ المكتبات المطلوبة غير مثبتة", "❌ المكتبات المطلوبة غير مثبتة"

    try:
        # تحويل bytes إلى صورة OpenCV
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            return "❌ تعذر قراءة الصورة", "❌ تعذر قراءة الصورة"

        # تحويل إلى تدرج الرمادي
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # تحسين التباين
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)

        # استخراج النص العربي
        arabic_config = r'--oem 3 --psm 6 -l ara'
        arabic_text = pytesseract.image_to_string(enhanced, config=arabic_config)

        # استخراج النص الإنجليزي
        english_config = r'--oem 3 --psm 6 -l eng'
        english_text = pytesseract.image_to_string(enhanced, config=english_config)

        # تنظيف النصوص
        arabic_text = re.sub(r'[^\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\s\d\-\.]', '', arabic_text)
        english_text = re.sub(r'[^a-zA-Z0-9\s\-\.]', '', english_text)

        return arabic_text.strip(), english_text.strip()

    except Exception as e:
        logger.error(f"خطأ في معالجة الصورة: {e}")
        return f"❌ خطأ في المعالجة: {str(e)}", ""

# ==================== معالجات البوت ====================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر /start"""
    user = update.effective_user

    welcome_message = f"""
🎉 *مرحباً {user.first_name}!*

*🤖 بوت استخراج بيانات الجوازات والبطاقات*

*✨ المميزات:*
• استخراج النصوص العربية والإنجليزية
• إنشاء بريد Gmail تلقائياً
• توليد كلمات مرور آمنة
• واجهة سهلة الاستخدام

*📸 *كيفية الاستخدام:*
1. أرسل صورة جواز السفر أو البطاقة
2. انتظر ثواني للمعالجة
3. احصل على النتائج كاملة

*⚡ *للبدء، أرسل صورة الآن!*
"""

    keyboard = [
        [InlineKeyboardButton("📸 أرسل صورة", callback_data="send_photo")],
        [InlineKeyboardButton("❓ المساعدة", callback_data="help")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        welcome_message,
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر /help"""
    help_text = """
*❓ *كيفية الحصول على أفضل نتائج:*

1. *📸 جودة الصورة:*
   • إضاءة جيدة بدون ظلال
   • الصورة أفقية وليست مائلة
   • خلفية فاتحة ومتجانسة

2. *🔍 نصائح للتصوير:*
   • اقترب من المستند
   • اجعله يملأ معظم الإطار
   • تأكد من وضوح النصوص

3. *📄 المستندات المدعومة:*
   • جوازات السفر
   • البطاقات الشخصية
   • رخص القيادة
   • أي مستند رسمي

4. *⚠️ المشاكل الشائعة:*
   • إذا لم يتم التعرف، جرب تصوير جزء فقط
   • تأكد من أن الصورة ليست مائلة
   • جرب إعادة التصوير بزاوية مختلفة

*📞 للدعم:* @your_username
"""

    await update.message.reply_text(help_text, parse_mode="Markdown")

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة الصور المرسلة"""
    user = update.effective_user

    try:
        # إرسال رسالة الانتظار
        wait_msg = await update.message.reply_text("⏳ *جاري معالجة الصورة...*", parse_mode="Markdown")

        # الحصول على الصورة
        photo_file = await update.message.photo[-1].get_file()
        image_bytes = await photo_file.download_as_bytearray()

        # تحديث الرسالة
        await wait_msg.edit_text("🔄 *جاري تحسين جودة الصورة...*")

        # استخراج النصوص من الصورة
        arabic_text, english_text = await process_image(image_bytes)

        # تحديث الرسالة
        await wait_msg.edit_text("🔍 *جاري استخراج البيانات...*")

        # استخراج الاسم
        processor = PassportProcessor()
        name = processor.extract_name_from_text(arabic_text, english_text)

        # إنشاء بريد Gmail
        gmail_address = processor.generate_gmail(name)

        # إنشاء كلمات المرور
        passwords = processor.generate_passwords(name)

        # حذف رسالة الانتظار
        await wait_msg.delete()

        # تحضير النتائج
        arabic_display = arabic_text[:300] if arabic_text and len(arabic_text) > 10 else "❌ لم يتم العثور على نص عربي واضح"
        english_display = english_text[:300] if english_text and len(english_text) > 10 else "❌ لم يتم العثور على نص إنجليزي واضح"

        # ✨ **بناء رسالة النتائج (بدون أخطاء)** ✨
        result_message = f"""
✅ *تم استخراج البيانات بنجاح!*

*📍 النص العربي:*